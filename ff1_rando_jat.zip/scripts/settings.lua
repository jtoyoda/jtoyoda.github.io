------------------------------------------------------------------
-- Configuration options for scripted systems in this pack
------------------------------------------------------------------
AUTOTRACKER_ENABLE_ITEM_TRACKING = true
AUTOTRACKER_ENABLE_LOCATION_TRACKING = true
AUTOTRACKER_ENABLE_SETTING_LOCATIONS_TO_FALSE = true

PREFERENCE_DISPLAY_ALL_LOCATIONS = true