# ff1-rando-jat
Final Fantasy 1 Randomizer Tracker

Tracker has 6 variants
- Map Tracker
- NOverworld Map Tracker
- No Map, Items/Locations only

-- All 3 above have a Shard tracker option

Built in autotracking for use with EmoTracker + BizHawk through use of a lua script. 

Some flag, location, and item options have multiple selections. Click or right click to cycle forward or backwards. 

The "L" with a number in the corner is an option to use to mark Loose Items.
- An option for Duds will come in a future update. 
- Both these flag settings have no effect on the map or items, pnly for visual reference. 

New flag options were added. They are in order as they appear on the rando generation site under the "Mode and World" tab, section labeled "Overworld Edits"
- Early and Extendted open are a single button to cycle through. 

Future updates planned:
Incentives with gated progression. (ie rod-locked)
- Unsure if able to function with Autotracker just yet, work in progress. (ie lots of digging through code)
An updated version of the NOverworld Map, hopefully with better map readability. 


If any of the logic is wonky, or something isnt functioning how you think it should, please reach out to me, @meklin89 in the FF1R Discord.

Enjoy!